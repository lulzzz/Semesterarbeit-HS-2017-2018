﻿using Arta;

namespace Simio
{
    public class Configuration
    {
        public static double correlationCoefficient;
        public static ArtaExecutionContext artaExecutionContext;
    }
}
