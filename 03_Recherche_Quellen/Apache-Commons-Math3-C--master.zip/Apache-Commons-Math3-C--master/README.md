﻿Apache Commons Math3 C# Porting
==========

This is a porting of Java [Apache Commons](http://commons.apache.org/) in C#.

I am going to port only the [Math3](http://commons.apache.org/proper/commons-math/) library.

This is a free time project with no warranties, please remember it.

Feel free to contribuite, if you want, all software is released under the [Apache License](http://www.apache.org/licenses/LICENSE-2.0).